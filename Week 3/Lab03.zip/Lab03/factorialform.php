<!DOCTYPE html>
<html lang="en" lang="en">

<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta name="description" content="Web Application Development :: Lab 3" />
    <meta name="keywords" content="Web,programming" />
    <meta name="author" content="Thanh Minh" />
    <title>Using if and while statements</title>
</head>

<body>
    <h1>Web Application Development - Lab 3</h1>
    <form action="factorial.php" method="GET">
        <label for="num">Input:</label>
        <input type="num" name="number" id="num">
        <input type="submit" value="Submit">
    </form>
</body>

</html>