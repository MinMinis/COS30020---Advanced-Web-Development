<!DOCTYPE html>
<html lang="en" lang="en">

<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta name="description" content="Web Application Development :: Lab 3" />
    <meta name="keywords" content="Web,programming" />
    <meta name="author" content="Thanh Minh" />
    <title>Task 3: Prime Number</title>
</head>

<body>
    <h1>Lab03 Task 3 - Prime Number</h1>
    <hr>
    <form action="primenumber.php" method="get">
        <label for="num">Input:</label>
        <input type="num" name="number" id="num">
        <input type="submit" value="Check for Prime Number">
    </form>
</body>

</html>