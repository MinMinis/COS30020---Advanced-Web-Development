<!DOCTYPE html>
<html lang="en" lang="en">

<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta name="description" content="Web Application Development :: Lab 3" />
    <meta name="keywords" content="Web,programming" />
    <meta name="author" content="Thanh Minh" />
    <title>Task 2: Leap Year</title>
</head>

<body>
    <h1>Lab03 Task 2 - Leap Year</h1>
    <hr>
    <form action="leapyear.php" method="post">
        <label for="num">Input:</label>
        <input type="num" name="number" id="num">
        <input type="submit" value="Check for Leap Year">
    </form>
</body>

</html>