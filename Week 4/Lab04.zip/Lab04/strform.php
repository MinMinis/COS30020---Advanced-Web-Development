<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="description" content="Web application development" />
    <meta name="keywords" content="PHP" />
    <meta name="author" content="Thanh Minh" />
    <title>Lab04 -Task 1</title>
</head>

<body>
    <h1>Web Programming Form - Lab 4</h1>
    <form action="strprocess.php" method="post">
        <label for="input">Input</label>
        <input type="text" id="input" name="input">
        <input type="submit" value="Submit">
    </form>
</body>

</html>