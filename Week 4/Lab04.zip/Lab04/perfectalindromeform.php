<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="description" content="Web application development" />
    <meta name="keywords" content="PHP" />
    <meta name="author" content="Thanh Minh" />
    <title>Lab04 - Task 2</title>
</head>

<body>
    <h1>Lab04 - Taks 2 Perfect Palindrome</h1>
    <hr>
    <form action="perfectpalindrome.php" method="post">
        <label for="input">Input</label>
        <input type="text" id="input" name="input">
        <br>
        <br>
        <input type="submit" value="Check for Perfect Palindrome">
    </form>
</body>

</html>