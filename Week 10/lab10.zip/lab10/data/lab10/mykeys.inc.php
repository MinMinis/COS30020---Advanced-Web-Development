<?php
$host = 'localhost';
$user = 'root';
$pswd = '';
$dbnm = 's103809048_db';
$table = 'hitcounter';
?>