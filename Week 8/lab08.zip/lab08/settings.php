<?php
$host = "feenix-mariadb.swin.edu.au";
$user = "s103809048";        //username 
$pswd = "se7en";        //password
$dbnm = "s103809048_db"; // my database
