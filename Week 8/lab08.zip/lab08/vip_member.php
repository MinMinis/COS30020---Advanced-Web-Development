<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="description" content="Web application development" />
    <meta name="keywords" content="PHP" />
    <meta name="author" content="Thanh Minh" />
    <title>Lab 08 Task 1</title>
</head>

<body>
    <h1>Web Programming - Lab08</h1>
    <h2>VIP member Registration System</h2>
    <a href="member_add_form.php">Add member</a>
    <a href="member_display.php">Display member</a>
    <a href="member_search.php">Search Member</a>
</body>

</html>