<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="description" content="Web application development" />
    <meta name="keywords" content="PHP" />
    <meta name="author" content="Thanh Minh" />
    <title>Week 5 - Task 1</title>
</head>

<body>
    <h1>Web Programming - Lab 5</h1>
    <hr>
    <form action="shoppingsave.php" method="POST">
        <label for="iname">Item Name</label>
        <input type="text" name="iname" id="iname">
        <br>
        <label for="iquantity">Quantity</label>
        <input type="text" name="iquantity" id="iquantity">
        <br>
        <input type="submit" value="Save">
    </form>
</body>

</html>