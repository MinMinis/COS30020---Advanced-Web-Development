<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Task 3 - Lab01</title>
</head>

<body>
    <h1>Forestville Credit Union</h1>
    <h2>CD Rates</h2>
    <?php 
			echo "<ul>";
				echo "<li>4.35% (36-Month Term CD)</li>";
				echo "<li>3.85% (12-Month Term CD)</li>";
				echo "<li>2.65% (6-Month term CD)</li>";
			echo "</ul>";
			echo "<p>$1,000 minimum deposit</p>";
			//Thanh Minh - 10/5/2023
		?>
</body>

</html>